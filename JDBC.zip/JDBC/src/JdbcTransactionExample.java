import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcTransactionExample {
    static final String DB_URL = "jdbc:mysql://localhost:3306/cmpdb";
    static final String DB_USER = "root";
    static final String DB_PASSWORD = "root";

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            conn.setAutoCommit(false);
            stmt = conn.createStatement();

            String insertSQL1 = "INSERT INTO emp VALUES(1009, 'Deepak Rathod', 'analyst', 40000, 30)";
            String insertSQL2 = "INSERT INTO emp VALUES(1010, 'Adarsh Nair', 'developer', 50000, 20)";
            String insertSQL3 = "INSERT INTO emp VALUES(1011, 'Ritesh Bobhate', 'manager', 60000, 40)";

            stmt.executeUpdate(insertSQL1);
            stmt.executeUpdate(insertSQL2);
            stmt.executeUpdate(insertSQL3);

            conn.commit();
            System.out.println("Transaction committed successfully.");

        } catch (SQLException se) {
            try {
                if (conn != null) conn.rollback();
                System.out.println("Transaction rolled back due to an error.");
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
            se.printStackTrace();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println("Goodbye!");
    }
}
