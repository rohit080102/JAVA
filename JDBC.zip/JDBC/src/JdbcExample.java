import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JdbcExample {
    static final String DB_URL = "jdbc:mysql://localhost:3306/cmpdb";
    static final String DB_USER = "root";
    static final String DB_PASSWORD = "root";

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            stmt = conn.createStatement();

            String createTableSQL = "CREATE TABLE IF NOT EXISTS emp (" +
                    "empno INTEGER PRIMARY KEY, " +
                    "name VARCHAR(20), " +
                    "job VARCHAR(20), " +
                    "salary INTEGER, " +
                    "deptno INTEGER)";
            stmt.executeUpdate(createTableSQL);

            String insertSQL1 = "INSERT INTO emp VALUES(1001, 'Amit Jain', 'clerk', 18000, 10)";
            String insertSQL2 = "INSERT INTO emp VALUES(1002, 'Gopal Pandey', 'manager', 450000, 20)";
            String insertSQL3 = "INSERT INTO emp VALUES(1003, 'Mona Mantri', 'clerk', 20000, 10)";
            String insertSQL4 = "INSERT INTO emp VALUES(1004, 'Raja Patil', 'driver', 15000, 40)";
            String insertSQL5 = "INSERT INTO emp VALUES(1005, 'Rohan Rathi', 'sr.clerk', 25000, 10)";
            stmt.executeUpdate(insertSQL1);
            stmt.executeUpdate(insertSQL2);
            stmt.executeUpdate(insertSQL3);
            stmt.executeUpdate(insertSQL4);
            stmt.executeUpdate(insertSQL5);

            String selectSQL = "SELECT * FROM emp";
            ResultSet rs = stmt.executeQuery(selectSQL);

            System.out.println("Data from 'emp' table:");
            while (rs.next()) {
                int empno = rs.getInt("empno");
                String name = rs.getString("name");
                String job = rs.getString("job");
                int salary = rs.getInt("salary");
                int deptno = rs.getInt("deptno");
                System.out.printf("EmpNo: %d, Name: %s, Job: %s, Salary: %d, DeptNo: %d%n", empno, name, job, salary, deptno);
            }
            rs.close();

        } catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println("Goodbye!");
    }
}
