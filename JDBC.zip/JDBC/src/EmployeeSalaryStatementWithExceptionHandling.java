import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

public class EmployeeSalaryStatementWithExceptionHandling {
    static final String DB_URL = "jdbc:mysql://localhost:3306/cmpdb";
    static final String DB_USER = "root";
    static final String DB_PASSWORD = "root";

    public static void main(String[] args) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            String query = "SELECT empno, name, base_salary, allowances, deductions FROM Emp_Sal";
            pstmt = conn.prepareStatement(query);
            rs = pstmt.executeQuery();

            System.out.printf("%-10s %-20s %-15s %-15s %-15s %-15s%n", 
                "EmpNo", "Name", "Base Salary", "Allowances", "Deductions", "Net Salary");
            System.out.println("-----------------------------------------------------------------------------------");

            while (rs.next()) {
                int empno = rs.getInt("empno");
                String name = rs.getString("name");
                double baseSalary = rs.getDouble("base_salary");
                double allowances = rs.getDouble("allowances");
                double deductions = rs.getDouble("deductions");
                double netSalary = baseSalary + allowances - deductions;

                System.out.printf("%-10d %-20s %-15.2f %-15.2f %-15.2f %-15.2f%n", 
                    empno, name, baseSalary, allowances, deductions, netSalary);
            }

        } catch (SQLIntegrityConstraintViolationException e) {
            System.out.println("Data integrity error: " + e.getMessage());
        } catch (SQLException e) {
            switch (e.getSQLState()) {
                case "08001":
                    System.out.println("Database connection error: " + e.getMessage());
                    break;
                case "42000":
                    System.out.println("SQL syntax error: " + e.getMessage());
                    break;
                default:
                    System.out.println("SQL error occurred: " + e.getMessage());
            }
        } catch (ClassNotFoundException e) {
            System.out.println("JDBC Driver not found: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.out.println("Error closing resources: " + e.getMessage());
            }
        }
    }
}
