import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CallableStatementExample {
    static final String DB_URL = "jdbc:mysql://localhost:3306/cmpdb";
    static final String DB_USER = "root";
    static final String DB_PASSWORD = "root";

    public static void main(String[] args) {
        Connection conn = null;
        CallableStatement cstmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            String sql = "{CALL getEmpDetailsByDept(?)}";
            cstmt = conn.prepareCall(sql);
            cstmt.setInt(1, 10);

            ResultSet rs = cstmt.executeQuery();

            while (rs.next()) {
                int empno = rs.getInt("empno");
                String name = rs.getString("name");
                String job = rs.getString("job");
                int salary = rs.getInt("salary");
                int deptno = rs.getInt("deptno");
                System.out.printf("EmpNo: %d, Name: %s, Job: %s, Salary: %d, DeptNo: %d%n", empno, name, job, salary, deptno);
            }
            rs.close();

        } catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (cstmt != null) cstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
    }
}
