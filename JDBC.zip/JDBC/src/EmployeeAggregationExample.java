import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EmployeeAggregationExample {
    static final String DB_URL = "jdbc:mysql://localhost:3306/cmpdb";
    static final String DB_USER = "root";
    static final String DB_PASSWORD = "root";

    public static void main(String[] args) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Perform COUNT, SUM, and AVG on base_salary column
            String query = "SELECT COUNT(*) AS emp_count, SUM(base_salary) AS total_salary, AVG(base_salary) AS avg_salary FROM Emp_Sal";
            pstmt = conn.prepareStatement(query);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                int employeeCount = rs.getInt("emp_count");
                double totalSalary = rs.getDouble("total_salary");
                double averageSalary = rs.getDouble("avg_salary");

                System.out.println("Employee Aggregation Results:");
                System.out.println("-------------------------------");
                System.out.printf("Total Employees: %d%n", employeeCount);
                System.out.printf("Sum of Salaries: %.2f%n", totalSalary);
                System.out.printf("Average Salary: %.2f%n", averageSalary);
            }

        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("JDBC Driver not found: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.out.println("Error closing resources: " + e.getMessage());
            }
        }
    }
}
