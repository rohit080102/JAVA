import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class HikariCPExample {
    private static HikariDataSource dataSource;

    static {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:mysql://localhost:3306/cmpdb");
        config.setUsername("root");
        config.setPassword("password");
        config.setMaximumPoolSize(10);
        dataSource = new HikariDataSource(config);
    }

    public static void main(String[] args) {
        String query = "SELECT * FROM emp";

        try (Connection conn = dataSource.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                int empno = rs.getInt("empno");
                String name = rs.getString("name");
                String job = rs.getString("job");
                int salary = rs.getInt("salary");
                int deptno = rs.getInt("deptno");
                System.out.printf("EmpNo: %d, Name: %s, Job: %s, Salary: %d, DeptNo: %d%n", empno, name, job, salary, deptno);
            }

        } catch (SQLException se) {
            se.printStackTrace();
        }
    }
}
