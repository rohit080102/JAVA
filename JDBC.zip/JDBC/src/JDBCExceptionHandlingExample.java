import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;

public class JDBCExceptionHandlingExample {
    static final String DB_URL = "jdbc:mysql://localhost:3306/cmpdb";
    static final String DB_USER = "root";
    static final String DB_PASSWORD = "root";

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            stmt = conn.createStatement();

            String sql = "INSERT INTO emp (empno, name, job, salary, deptno) VALUES (1009, 'John Doe', 'Analyst', 40000, 10)";
            stmt.executeUpdate(sql);

        } catch (SQLIntegrityConstraintViolationException e) {
            System.out.println("Data integrity error: Duplicate entry or constraint violation. " + e.getMessage());
        } catch (SQLException e) {
            switch (e.getSQLState()) {
                case "08001":
                    System.out.println("Database connection error: " + e.getMessage());
                    break;
                case "42000":
                    System.out.println("SQL syntax error: " + e.getMessage());
                    break;
                default:
                    System.out.println("SQL error occurred: " + e.getMessage());
            }
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.out.println("Error closing resources: " + e.getMessage());
            }
        }
    }
}
