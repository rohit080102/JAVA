import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class EmployeeCRUDApp {
    static final String DB_URL = "jdbc:mysql://localhost:3306/cmpdb";
    static final String DB_USER = "root";
    static final String DB_PASSWORD = "root";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            Class.forName("com.mysql.cj.jdbc.Driver");

            boolean exit = false;
            while (!exit) {
                System.out.println("\nEmployee CRUD Operations:");
                System.out.println("1. Create Employee");
                System.out.println("2. Read All Employees");
                System.out.println("3. Update Employee Salary");
                System.out.println("4. Delete Employee");
                System.out.println("5. Exit");
                System.out.print("Select an option: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); 

                switch (choice) {
                    case 1:
                        createEmployee(conn, scanner);
                        break;
                    case 2:
                        readAllEmployees(conn);
                        break;
                    case 3:
                        updateEmployeeSalary(conn, scanner);
                        break;
                    case 4:
                        deleteEmployee(conn, scanner);
                        break;
                    case 5:
                        exit = true;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }

    public static void createEmployee(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter employee name: ");
            String name = scanner.nextLine();
            System.out.print("Enter position: ");
            String position = scanner.nextLine();
            System.out.print("Enter salary: ");
            double salary = scanner.nextDouble();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter department: ");
            String department = scanner.nextLine();

            String insertSQL = "INSERT INTO Employee (name, position, salary, department) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
                pstmt.setString(1, name);
                pstmt.setString(2, position);
                pstmt.setDouble(3, salary);
                pstmt.setString(4, department);
                int rows = pstmt.executeUpdate();
                System.out.println("Inserted " + rows + " row(s) successfully.");
            }
        } catch (SQLException e) {
            System.out.println("Error inserting employee: " + e.getMessage());
        }
    }

    public static void readAllEmployees(Connection conn) {
        String selectSQL = "SELECT * FROM Employee";
        try (PreparedStatement pstmt = conn.prepareStatement(selectSQL);
             ResultSet rs = pstmt.executeQuery()) {

            System.out.println("\nEmployee Records:");
            System.out.printf("%-5s %-20s %-20s %-10s %-15s%n", "ID", "Name", "Position", "Salary", "Department");
            System.out.println("------------------------------------------------------------");
            while (rs.next()) {
                int id = rs.getInt("emp_id");
                String name = rs.getString("name");
                String position = rs.getString("position");
                double salary = rs.getDouble("salary");
                String department = rs.getString("department");
                System.out.printf("%-5d %-20s %-20s %-10.2f %-15s%n", id, name, position, salary, department);
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving employees: " + e.getMessage());
        }
    }

    public static void updateEmployeeSalary(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter employee ID to update: ");
            int empId = scanner.nextInt();
            System.out.print("Enter new salary: ");
            double newSalary = scanner.nextDouble();

            String updateSQL = "UPDATE Employee SET salary = ? WHERE emp_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(updateSQL)) {
                pstmt.setDouble(1, newSalary);
                pstmt.setInt(2, empId);
                int rows = pstmt.executeUpdate();
                if (rows > 0) {
                    System.out.println("Updated employee salary successfully.");
                } else {
                    System.out.println("Employee not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error updating employee salary: " + e.getMessage());
        }
    }

    public static void deleteEmployee(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter employee ID to delete: ");
            int empId = scanner.nextInt();

            String deleteSQL = "DELETE FROM Employee WHERE emp_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(deleteSQL)) {
                pstmt.setInt(1, empId);
                int rows = pstmt.executeUpdate();
                if (rows > 0) {
                    System.out.println("Deleted employee successfully.");
                } else {
                    System.out.println("Employee not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error deleting employee: " + e.getMessage());
        }
    }
}
